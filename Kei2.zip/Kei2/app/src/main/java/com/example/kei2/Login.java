package com.example.kei2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;

public class Login extends AppCompatActivity {

    Button callSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

Button login_btn = (Button) findViewById(R.id.login_btn);
login_btn.setOnClickListener((v) -> {
    Toast notificacion = Toast.makeText(Login.this, "Bienvenido a KeiSoft", Toast.LENGTH_SHORT);
    notificacion.show();
    Intent intencion = new Intent(getApplicationContext(), MainActivity2.class);
    startActivity(intencion);
});

Button register_btn = (Button) findViewById(R.id.boton_register);
register_btn.setOnClickListener((v) ->{
    Toast notificacion = Toast.makeText(Login.this, "Bienvenido a KeiSoft", Toast.LENGTH_SHORT);
    notificacion.show();
    Intent intencion = new Intent(getApplicationContext(), Register.class);
    startActivity(intencion);
});
        /*callSignUp = findViewById(R.id.signup_screen);
        callSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, Register.class);
               startActivity(intent);
            }
        });*/

    }
}