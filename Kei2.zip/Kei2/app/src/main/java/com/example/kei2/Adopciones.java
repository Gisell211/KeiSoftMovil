package com.example.kei2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.kei2.Adaptador.AdaptadorEspecies;
import com.example.kei2.Adaptador.AdaptadorRetrofit;
import com.example.kei2.Modelo.Especie;
import com.example.kei2.Retrofit_Data.APIRest;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class Adopciones extends AppCompatActivity {

    EditText etIdBuscar, etId, etNombre, etEdad, etRaza, etGenero, etTipoAnimal, etImagen;
    Button btnBuscar, btnEliminar, btnTodosBuscar, btnAgregar, btnEditar;

    RecyclerView rvEspecie;
    List<Especie> listaAnimales = new ArrayList<>();

    AdaptadorEspecies adaptadorEspecie;
    Retrofit retrofit;
    APIRest api;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adopciones);

        /*getSupportActionBar().hide(); no me emula si hay esto*/

        etIdBuscar = findViewById(R.id.etIdBuscar);
        etId = findViewById(R.id.etId);
        etNombre = findViewById(R.id.etNombre);
        etEdad = findViewById(R.id.etEdad);
        etRaza = findViewById(R.id.etRaza);
        etGenero = findViewById(R.id.etGenero);
        etTipoAnimal = findViewById(R.id.etTipoAnimal);
        etImagen = findViewById(R.id.etImagen);

        btnBuscar = findViewById(R.id.btnIdBuscar);
        btnEliminar = findViewById(R.id.btnEliminar);
        btnTodosBuscar = findViewById(R.id.btnTodosBuscar);
        btnAgregar = findViewById(R.id.btnAgregar);
        btnEditar = findViewById(R.id.btnEditar);

        rvEspecie = findViewById(R.id.rvEspecies);
        rvEspecie.setLayoutManager(new GridLayoutManager(this, 1));

        retrofit = new AdaptadorRetrofit().getAdaptador();
        api= retrofit.create(APIRest.class);

        getEspecies(api);
        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etIdBuscar.getText().toString().equals("")){
                    Toast.makeText(Adopciones.this, "Inserta un ID para buscar", Toast.LENGTH_SHORT).show();
                }else {
                    getEspecie(api, etIdBuscar.getText().toString());
                }
            }
        });

        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etIdBuscar.getText().toString().equals("")){
                    Toast.makeText(Adopciones.this, "Inserta un ID para eliminar", Toast.LENGTH_SHORT).show();
                }else {
                    eliminarAnimal(api, etIdBuscar.getText().toString());
                }
            }
        });

        btnTodosBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getEspecies(api);
            }
        });

        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etNombre.getText().toString().equals("") ||
                        etEdad.getText().toString().equals("") ||
                        etRaza.getText().toString().equals("")||
                        etGenero.getText().toString().equals("") ||
                        etTipoAnimal.getText().toString().equals("") ||
                        etImagen.getText().toString().equals("")){
                    Toast.makeText(Adopciones.this, "se debe llenar los campos", Toast.LENGTH_SHORT).show();
                }else {
                    agregarAnimal (api, etId.getText().toString(),
                            etNombre.getText().toString(),
                            etEdad.getText().toString(),
                            etRaza.getText().toString(),
                            etGenero.getText().toString(),
                            etTipoAnimal.getText().toString(),
                            etImagen.getText().toString());
                }
            }
        });
        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (etId.getText().toString().equals("") ||
                        etNombre.getText().toString().equals("") ||
                        etEdad.getText().toString().equals("") ||
                        etRaza.getText().toString().equals("")||
                        etGenero.getText().toString().equals("") ||
                        etTipoAnimal.getText().toString().equals("") ||
                        etImagen.getText().toString().equals("")){
                    Toast.makeText(Adopciones.this, "Se deben llenar los campos", Toast.LENGTH_SHORT).show();
                } else {
                    editarAnimal(api, etId.getText().toString(),
                            etNombre.getText().toString(),
                            etEdad.getText().toString(),
                            etRaza.getText().toString(),
                            etGenero.getText().toString(),
                            etTipoAnimal.getText().toString(),
                            etImagen.getText().toString());
                }
            }
        });
    }
    public void getEspecie(final APIRest api, String id){
        listaAnimales.clear();
        Call<Especie> call = api.obtenerAnimale(id);
        call.enqueue(new Callback<Especie>() {
            @Override
            public void onResponse(Call<Especie> call, Response<Especie> response) {
                switch (response.code()){
                    case 200:
                        listaAnimales.add(response.body());
                        etIdBuscar.setText("");
                        adaptadorEspecie = new AdaptadorEspecies(Adopciones.this, listaAnimales);
                        rvEspecie.setAdapter(adaptadorEspecie);
                        break;
                    case 204:
                        Toast.makeText(Adopciones.this, "No existe ese registro", Toast.LENGTH_SHORT).show();
                        etIdBuscar.setText("");
                        getEspecies(api);
                        break;
                }
            }

            @Override
            public void onFailure(Call<Especie> call, Throwable t) {
            }
        });
    }
    public void getEspecies(APIRest api){
        listaAnimales.clear();
        Call<List<Especie>> call = api.obtenerAnimales();
        call.enqueue(new Callback<List<Especie>>() {
            @Override
            public void onResponse(Call<List<Especie>> call, Response<List<Especie>> response) {
                listaAnimales = new ArrayList<Especie>(response.body());
                adaptadorEspecie = new AdaptadorEspecies(Adopciones.this, listaAnimales);
                rvEspecie.setAdapter(adaptadorEspecie);
            }
            @Override
            public void onFailure(Call<List<Especie>> call, Throwable t) {
            }
        });
    }
    public void eliminarAnimal(final APIRest api, String id){
        listaAnimales.clear();
        Call<Void> call = api.eliminarEspecie(id);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                switch (response.code()){
                    case 200:
                        Toast.makeText(Adopciones.this, "Se elimino correctamente", Toast.LENGTH_SHORT).show();
                        etIdBuscar.setText("");
                        getEspecies(api);
                        break;
                    case 204:
                        Toast.makeText(Adopciones.this, "No se encontro el registro", Toast.LENGTH_SHORT).show();
                        etIdBuscar.setText("");
                        getEspecies(api);
                        break;
                }
            }
            @Override
            public void onFailure(Call<Void> call, Throwable t) {
            }
        });
    }
    public void  agregarAnimal(final APIRest api, String nombre, String edad, String raza,
                               String genero, String tipoAnimal, String imagen, String s){
        listaAnimales.clear();
        Especie especie = new Especie();
        especie.setNombre(nombre);
        especie.setEdad(edad);
        especie.setRaza(raza);
        especie.setGenero(genero);
        especie.setTipoAnimal(tipoAnimal);
        especie.setImagen(imagen);

        Call<Void> call = api.agregarAnimale(especie);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                switch (response.code()){
                    case 400:
                        Toast.makeText(Adopciones.this, "Faltaron campos", Toast.LENGTH_SHORT).show();
                        break;
                    case 200:
                        Toast.makeText(Adopciones.this, "Se inserto correctamente", Toast.LENGTH_SHORT).show();
                        etNombre.setText("");
                        etEdad.setText("");
                        etRaza.setText("");
                        etGenero.setText("");
                        etTipoAnimal.setText("");
                        etImagen.setText("");
                        getEspecies(api);
                }
            }
            @Override
            public void onFailure(Call<Void> call, Throwable t) {
            }
        });
    }
    public void editarAnimal(final APIRest api, String id,String nombre, String edad, String raza,
                             String genero, String tipoAnimal, String imagen){
        listaAnimales.clear();
        Especie especie = new Especie();
        especie.setId(id);
        especie.setNombre(nombre);
        especie.setEdad(edad);
        especie.setRaza(raza);
        especie.setGenero(genero);
        especie.setTipoAnimal(tipoAnimal);
        especie.setImagen(imagen);

        Call<Void> call = api.editarAnimale(especie);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
              switch (response.code()){
                  case 400:
                      Toast.makeText(Adopciones.this, "No se puede editar", Toast.LENGTH_SHORT).show();
                      etId.setText("");
                      etNombre.setText("");
                      etEdad.setText("");
                      etRaza.setText("");
                      etGenero.setText("");
                      etTipoAnimal.setText("");
                      etImagen.setText("");
                      break;
                  case 200:
                      Toast.makeText(Adopciones.this, "Se edito correctamente", Toast.LENGTH_SHORT).show();
                      etId.setText("");
                      etNombre.setText("");
                      etEdad.setText("");
                      etRaza.setText("");
                      etGenero.setText("");
                      etTipoAnimal.setText("");
                      etImagen.setText("");
                      getEspecies(api);
                      break;
              }
            }
            @Override
            public void onFailure(Call<Void> call, Throwable t) {

            }
        });
    }
}