package com.example.kei2.Adaptador;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.kei2.Modelo.Especie;
import com.example.kei2.R;

import java.util.List;

public class AdaptadorEspecies extends RecyclerView.Adapter<AdaptadorEspecies.EspeciesViewHolder> {

   Context context;
   List<Especie> listaAnimales;

    public AdaptadorEspecies(Context context, List<Especie> listaAnimales) {
        this.context = context;
        this.listaAnimales = listaAnimales;
    }
    @NonNull
    @Override
    public AdaptadorEspecies.EspeciesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_rv_especie, null, false);
      return  new AdaptadorEspecies.EspeciesViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorEspecies.EspeciesViewHolder holder, int position) {
     holder.tvIdEspecie.setText(listaAnimales.get(position).getId());
     holder.tvNombre.setText(listaAnimales.get(position).getNombre());
    }

    @Override
    public int getItemCount() {
        return listaAnimales.size();
    }

    public class EspeciesViewHolder extends RecyclerView.ViewHolder {
       TextView tvIdEspecie, tvNombre;
        public EspeciesViewHolder(@NonNull View itemView) {
            super(itemView);

            tvIdEspecie=itemView.findViewById(R.id.tvIdEspecie);
            tvNombre=itemView.findViewById(R.id.tvNombre);
        }
    }
}
