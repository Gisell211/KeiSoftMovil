package com.example.kei2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DetalleProducto2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_producto2);
    }
}