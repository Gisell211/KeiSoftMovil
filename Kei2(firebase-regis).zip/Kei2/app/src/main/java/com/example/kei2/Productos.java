package com.example.kei2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Productos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productos);
    }
    public void Detalle(View view){
        Intent intent = new Intent(Productos.this, DetalleProducto1.class);
        startActivity(intent);
    }
}