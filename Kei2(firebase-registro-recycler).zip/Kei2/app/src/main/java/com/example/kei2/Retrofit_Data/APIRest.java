package com.example.kei2.Retrofit_Data;
import com.example.kei2.Modelo.Especie;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;

public interface APIRest {
    String URL_PHP ="especie/";

    @GET(URL_PHP)
    Call<List<Especie>> obtenerAnimales();

    @GET(URL_PHP)
    Call <Especie> obtenerAnimale(
            @Query("idEspecie") String id
    );

    @POST(URL_PHP)
    Call<Void> agregarAnimale(
            @Body Especie especie
    );

    @PUT(URL_PHP)
    Call<Void> editarAnimale(
            @Body Especie especie
    );

    @DELETE(URL_PHP)
    Call<Void> eliminarEspecie( @Query("idEspecie") String id
    );
}